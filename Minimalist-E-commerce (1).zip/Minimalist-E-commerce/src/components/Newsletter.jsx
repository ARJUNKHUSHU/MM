import "./Newsletter.css";

function Newsletter() {
  return (
    <>
      
    </>
  );
}

export default Newsletter;
