import { Link } from "react-router-dom";
import "./Footer.css";

function Footer() {
  return (
    <>
      <footer>
        <div className="footer-links">
          <Link to="/categories/all">category</Link>
          <Link to="/categories/product/19">product</Link>
          <Link to="/signin">signin</Link>
          
        </div>
      </footer>
    </>
  );
}

export default Footer;
