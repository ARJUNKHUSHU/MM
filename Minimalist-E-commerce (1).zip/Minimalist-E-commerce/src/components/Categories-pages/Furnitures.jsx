import CategoriesItemFurniture from "./CategoriesItemFurniture";
import Footer from "../Footer";
import Newsletter from "../Newsletter";

function Furnitures() {
  return (
    <>
      <CategoriesItemFurniture />
      <Newsletter />
      <Footer />
    </>
  );
}

export default Furnitures;
